<?php 
error_reporting(E_ALL ^ E_NOTICE); // hide all basic notices from PHP

//If the form is submitted
if(isset($_POST['submitted'])) {
  
  // require a name from user
  if(trim($_POST['name']) === '') {
    $nameError =  'Forgot your name!'; 
    $hasError = true;
  } else {
    $name = trim($_POST['name']);
  }
  
  // need valid email
  if(trim($_POST['email']) === '')  {
    $emailError = 'Forgot to enter in your e-mail address.';
    $hasError = true;
  } else if (!preg_match("/^[[:alnum:]][a-z0-9_.-]*@[a-z0-9.-]+\.[a-z]{2,4}$/i", trim($_POST['email']))) {
    $emailError = 'You entered an invalid email address.';
    $hasError = true;
  } else {
    $email = trim($_POST['email']);
  }
    
  // we need at least some content
  if(trim($_POST['message']) === '') {
    $commentError = 'You forgot to enter a message!';
    $hasError = true;
  } else {
    if(function_exists('stripslashes')) {
      $comments = stripslashes(trim($_POST['message']));
    } else {
      $comments = trim($_POST['message']);
    }
  }
    
  // upon no failure errors let's email now!
  if(!isset($hasError)) {

    /*---------------------------------------------------------*/
    /* SET EMAIL YOUR EMAIL ADDRESS HERE                       */
    /*---------------------------------------------------------*/
    $emailTo = 'cagipple@gmail.com';
    $subject = 'Submitted message from '.$name;
    $sendCopy = trim($_POST['sendCopy']);
    $body = "Name: $name \n\nEmail: $email \n\nMessage: $comments";
    $headers = 'From: ' .' <'.$emailTo.'>' . "\r\n" . 'Reply-To: ' . $email;

    mail($emailTo, $subject, $body, $headers);
        
        // set our boolean completion value to TRUE
    $emailSent = true;
  }
}
?>

<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="description" content="Vertex, singple page mobile app theme.">
<meta name="keywords" content="vertex, theme, app, single page">
<meta name="author" content="rype pixel">
<meta name="viewport" content="width=device-width, initial-scale=1.0">	
<title>Vertex | Single Page App Theme</title>
<script src="js/html5shiv.js"></script>  <!-- support for HTML5 in IE8 -->
<!-- CSS file links -->
<link href="css/bootstrap.min.css" rel="stylesheet" media="screen">
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" id="styleChange" />
<link href="css/jquery.bxslider.css" rel="stylesheet" />
<link href="css/lightbox.css" type="text/css" rel="stylesheet" />
<link href="css/responsive.css" type="text/css" rel="stylesheet" />
</head>

<body>

	<!-- Header Start -->
     <header class="navbar navbar-default navbar-fixed-top">
      	<div class="container">
        	<div class="navbar-header">
          		<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            	<span class="icon-bar"></span>
            	<span class="icon-bar"></span>
            	<span class="icon-bar"></span>
          		</button>
          		<a class="navbar-brand" href="#"></a>
        	</div>
        	<div class="navbar-collapse collapse">
          		<ul class="nav navbar-nav navbar-right">
            		<li class="current"><a href="#sliderAnchor">Home</a></li>
            		<li><a href="#featuresAnchor">Features</a></li>
            		<li><a href="#screenshotsAnchor">Screenshots</a></li>
            		<li><a href="#howItWorksAnchor">How It Works</a></li>
            		<li><a href="#pricingAnchor">Pricing</a></li>
            		<li><a href="#faqAnchor">Faq</a></li>
            		<li><a href="#ourTeamAnchor">Our Team</a></li>
            		<li><a href="#contactAnchor" style="padding-right:0px;">Contact</a></li>
          		</ul>
        	</div><!--/.navbar-collapse -->
      </div><!-- END Container -->
    </header><!-- END Header -->

    <!-- Slider Start -->
    <a class="anchor" id="sliderAnchor"></a>
    <section class="jumbotron">
    	<div class="container">

          <ul class="slides" style="display:none;">
            <li>
            <div class="col-lg-6">
              <img id="iphoneBlack" class="img-responsive" src="images/iphoneBlack.png" alt="iphone" />
              <img id="iphoneWhite" class="img-responsive" src="images/iphoneWhite.png" alt="iphone" />
            </div>
        		<div class="col-lg-6 slideText">
          		<h1><span>Showcase</span> Your App</h1>
          		<p>Vertex is the <span>perfect template</span> to showcase your iPhone or Android app.</p><br/>
          		<a href="#" class="button">Download Vertex</a>
      		  </div>
          </li><!-- END Slide 1 -->
          <li>
            <div class="col-lg-6">
              <img id="ipadWhite" src="images/ipadWhite.png" alt="ipad white" />
              <img id="ipadBlack" src="images/ipadBlack.png" alt="ipad black" />
              <img id="iphoneBlackSmall" src="images/iphoneBlackSmall.png" alt="iphone" />
            </div>
            <div class="col-lg-5 col-lg-offset-1 slideText">
              <h1><span>Connect &amp; share</span> easier then ever.</h1>
              <p>Join a growing community on Vertex using the iPad, 
              iPhone, Andriod and web. Lorem ipsum dolor sit amet, 
              consectetur adipiscing elit. Lorem ipsum dolor sit amet, 
              consectetur adipiscing elit </p>
              <form>
                <input type="text" name="email" value="Your email" id="emailInputSlider" style="margin-right:0px" /><br/>
                <input type="submit" name="submit" value="Start Your Free Trial" class="buttonSmall" id="buttonSmallSlider" />
              </form>
          </div>
          </li><!-- END Slide 2 -->
          <li style="text-align:center;">
            <h1><span>Vertex</span> is an incredible app</h1>
            <p>Join our community and start <span>exploring</span> today on iPad, iPhone or Android</p>
            <img id="bubbleGraphic" src="images/bubbleGraphic.png" alt="" />
            <ul id="slideThreeList">
              <li>Upload</li>
              <li>Share</li>
              <li>Connect</li>
            </ul>
          </li>
        </ul> 

    	</div><!-- END Container -->

      <div class="sliderControls">
          <span id="slider-prev"></span>
          <span id="slider-next"></span>
        </div>

    </section><!-- END Slider -->

    <!-- sub-slider message Start -->
    <section id="subSliderMessage">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <h2>Vertex will allow you to <span>connect, interact</span> and <span>share</span> in a whole new way</h2>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras amet rhoncus tortor. Phasellus in auctor tellus. Pellentesque laoreet, eros at, iaculis massa. </p>
          </div>
        </div>
      </div><!-- END container -->
    </section><!-- END Sub-slider message -->

    <!-- Features Start -->
    <a class="anchor" id="featuresAnchor"></a>
    <section id="features">
      <div class="container">
        <div class="row"><div class="col-lg-12"><h3>Features</h3></div><div class="col-lg-12"><img class="dividerWide" src="images/divider.png" alt=""></div></div>
        <div class="row">
          <div class="col-lg-4 featureItem">
            <div class="featureIcon" id="addUserIcon"></div>
            <h4>Share &amp; Connect</h4>
            <p>Lorem ipsum dolor sit quis amet, consectetur adipiscing elit. Aenean leo lectus sollicitudin convallis quis eget libero. Aliquam laoreet tellus ut libero semper, egestas velit malesuada.  </p>
            <p><a class="btn btn-default" href="#">View details &raquo;</a></p>
          </div>
          <div class="col-lg-4 featureItem">
            <div class="featureIcon" id="cloudIcon"></div>
            <h4>Access Date Anywhere</h4>
            <p>Lorem ipsum dolor sit quis amet, consectetur adipiscing elit. Aenean leo lectus sollicitudin convallis quis eget libero. Aliquam laoreet tellus ut libero semper, egestas velit malesuada.  </p>
            <p><a class="btn btn-default" href="#">View details &raquo;</a></p>
         </div>
          <div class="col-lg-4 featureItem">
            <div class="featureIcon" id="gearIcon"></div>
            <h4>Customize Your Profile</h4>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean quis leo lectus sollicitudin convallis quis eget libero. Aliquam laoreet tellus ut libero semper, egestas velit malesuada.  </p>
            <p><a class="btn btn-default" href="#">View details &raquo;</a></p>
          </div>
        </div><!-- END Row -->
        <div class="row">
          <div class="col-lg-4 featureItem">
            <div class="featureIcon" id="uploadIcon"></div>
            <h4>Quick &amp; Easy File Upload</h4>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean quis leo lectus sollicitudin convallis quis eget libero. Aliquam laoreet tellus ut libero semper, egestas velit malesuada.  </p>
            <p><a class="btn btn-default" href="#">View details &raquo;</a></p>
          </div>
          <div class="col-lg-4 featureItem">
            <div class="featureIcon" id="messageIcon"></div>
            <h4>Interactive Chat</h4>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean quis leo lectus sollicitudin convallis quis eget libero. Aliquam laoreet tellus ut libero semper, egestas velit malesuada.  </p>
            <p><a class="btn btn-default" href="#">View details &raquo;</a></p>
          </div>
          <div class="col-lg-4 featureItem">
            <div class="featureIcon" id="connectIcon"></div>
            <h4>Growing Community</h4>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean quis leo lectus sollicitudin convallis quis eget libero. Aliquam laoreet tellus ut libero semper, egestas velit malesuada.  </p>
            <p><a class="btn btn-default" href="#">View details &raquo;</a></p>
          </div>
        </div><!-- END Row -->
      </div><!-- END Container -->
    </section><!-- END Features -->

    <!-- Start Screenshots -->
    <a class="anchor" id="screenshotsAnchor"></a>
    <section id="screenshots">
      <div class="container">
        <div class="row"><div class="col-lg-12"><h3>Screenshots</h3></div><div class="col-lg-12"><img class="dividerWide" src="images/divider.png" alt=""></div></div>
        <div class="row">
          <div class="col-lg-3">
              <div class="image">
              <img src="images/screenshot1.png" class="screenshotImage" alt="placeholder" />
              <a href="images/screenshot1.png" data-lightbox="screenshot1" title="This is a caption" class="overlay"><img class="linkIcon" src="images/icons/linkIcon.png" alt="" /></a>
              </div>
            <h4>Share &amp; Connect</h4>
            <p>Lorem ipsum leo dolor lectus amet, consectetur adipiscing elit. Aenean quis leo sollicitudin convallis quis eget libero. Aliquam laoreet tellus ut libero semper, egestas velit elit malesuada.  </p>
          </div>
          <div class="col-lg-3">
            <div class="image">
            <img src="images/screenshot2.png" class="screenshotImage" alt="placeholder" />
            <a href="images/screenshot2.png" data-lightbox="screenshot2" title="This is a caption" class="overlay"><img class="linkIcon" src="images/icons/linkIcon.png" alt="" /></a>
            </div>
            <h4>File Upload</h4>
            <p>Lorem ipsum leo dolor lectus amet, consectetur adipiscing elit. Aenean quis leo sollicitudin convallis quis eget libero. Aliquam laoreet tellus ut libero semper, egestas velit elit malesuada.  </p>
          </div>
          <div class="col-lg-3">
            <div class="image">
              <img src="images/screenshot3.png" class="screenshotImage" alt="placeholder" />
              <a href="images/screenshot3.png" data-lightbox="screenshot3" title="This is a caption" class="overlay"><img class="linkIcon" src="images/icons/linkIcon.png" alt="" /></a>
            </div>
            <h4>Interactive Chat</h4>
            <p>Lorem ipsum leo dolor lectus amet, consectetur adipiscing elit. Aenean quis leo sollicitudin convallis quis eget libero. Aliquam laoreet tellus ut libero semper, egestas velit elit malesuada.  </p>
          </div>
          <div class="col-lg-3">
            <div class="image">
              <img src="images/screenshot4.png" class="screenshotImage" alt="placeholder" />
              <a href="images/screenshot4.png" data-lightbox="screenshot4" title="This is a caption" class="overlay"><img class="linkIcon" src="images/icons/linkIcon.png" alt="" /></a>
            </div>
            <h4>Notifications</h4>
            <p>Lorem ipsum leo dolor lectus amet, consectetur adipiscing elit. Aenean quis leo sollicitudin convallis quis eget libero. Aliquam laoreet tellus ut libero semper, egestas velit elit malesuada.  </p>
          </div>
        </div><!-- END Row -->
      </div><!-- END Container -->
    </section><!-- END Screenshots -->

    <!-- Start Promo box -->
    <section id="promoBox">
      <div class="container">
        <div class="row">
          <div class="col-lg-6">
            <h4>Try out the <span>free trial</span> today.</h4>
            <p>Lorem ipsum dolor ut, consectetur adipiscing. Aenean quis lectus sollicitudin.</p>
          </div>
          <div class="col-lg-6">
            <form name="subscribeForm" id="subscribeForm" action="#" novalidate>
                  <input type="email" name="email" id="emailInput" placeholder="your email here" value="">
                  <input type="submit" id="subscribeButton" value="Subscribe">
            </form>
          </div>
        </div><!-- END Row -->
      </div><!-- END container -->
    </section><!-- END Promo box -->

    <!-- Start How It Works -->
    <a class="anchor" id="howItWorksAnchor"></a>
    <section id="howItWorks">
      <div class="container">
        <div class="row"><div class="col-lg-12"><h3>How It Works</h3></div><div class="col-lg-12"><img class="dividerWide" src="images/divider.png" alt=""></div></div>
        <div class="row">
          <div class="col-lg-6 howItWorksGraphic">
            <img class="iphoneSmall" src="images/iphoneMagnify.png" alt="iphone" />
            <img class="dividerHalf" src="images/dividerHalf.png" alt="divider" />
          </div>
          <div class="col-lg-6">
            <h4>Upload your files. <span>Anywhere, anytime.</span></h4><br/>
            <p>Lorem ipsum dolor amet, consectetur adipiscing elit. Aenean leo lectus sollicitudin 
            convallis quis eget libero. Aliquam laoreet tellus ut libero semper, egestas velit 
            malesuada. Sed non risus eget dolor vestibulum ullamcorper. Integer feugiat at 
            massa sit amet molestie. Fusce varius tincidunt metus ac accumsan. Sed varius 
            pharetra risus ac scelerisque. Nulla facilisi. Nulla facilisi. Vivamus metus lorem, 
            pellentesque a accumsan quis, imperdiet nec quam. Sed non risus eget dolor 
            vestibulum ullamcorper. Integer feugiat at massa sit amet molestie. Fusce varius 
            tincidunt metus ac accumsan.</p>
          </div>
        </div><!-- END Row -->
        <div class="transition1"></div>
        <div class="row">
          <div class="col-lg-6">
            <h4>Share with a <span>growing community.</span></h4><br/>
            <p>Lorem ipsum dolor amet, consectetur adipiscing elit. Aenean leo lectus sollicitudin 
            convallis quis eget libero. Aliquam laoreet tellus ut libero semper, egestas velit 
            malesuada. Sed non risus eget dolor vestibulum ullamcorper. Integer feugiat at 
            massa sit amet molestie. Fusce varius tincidunt metus ac accumsan. Sed varius 
            pharetra risus ac scelerisque. Nulla facilisi. Nulla facilisi. Vivamus metus lorem, 
            pellentesque a accumsan quis, imperdiet nec quam. Sed non risus eget dolor 
            vestibulum ullamcorper. Integer feugiat at massa sit amet molestie. Fusce varius 
            tincidunt metus ac accumsan.</p>
          </div>
          <div class="col-lg-6 howItWorksGraphic">
            <img class="iphoneSmall" src="images/iphoneMagnify.png" alt="iphone" />
            <img class="dividerHalf" src="images/dividerHalf.png" alt="divider" />
          </div>
        </div><!-- END Row -->
        <div class="transition2"></div>
        <div class="row">
          <div class="col-lg-6 howItWorksGraphic">
            <img class="iphoneSmall" src="images/iphoneMagnify.png" alt="iphone" />
            <img class="dividerHalf" src="images/dividerHalf.png" alt="divider" />
          </div>
          <div class="col-lg-6">
            <h4><span>Follow</span> your favorite people.</h4><br/>
            <p>Lorem ipsum dolor amet, consectetur adipiscing elit. Aenean leo lectus sollicitudin 
            convallis quis eget libero. Aliquam laoreet tellus ut libero semper, egestas velit 
            malesuada. Sed non risus eget dolor vestibulum ullamcorper. Integer feugiat at 
            massa sit amet molestie. Fusce varius tincidunt metus ac accumsan. Sed varius 
            pharetra risus ac scelerisque. Nulla facilisi. Nulla facilisi. Vivamus metus lorem, 
            pellentesque a accumsan quis, imperdiet nec quam. Sed non risus eget dolor 
            vestibulum ullamcorper. Integer feugiat at massa sit amet molestie. Fusce varius 
            tincidunt metus ac accumsan.</p>
          </div>
        </div><!-- END Row -->
      </div><!-- END Container -->
    </section><!-- END How It Works -->

    <!-- Start Pricing -->
    <a class="anchor" id="pricingAnchor"></a>
    <section id="pricing">
      <div class="container">
        <div class="row"><div class="col-lg-12"><h3>Pricing Options</h3></div><div class="col-lg-12"><img class="dividerWide" src="images/divider.png" alt=""></div></div>
          <div class="row">

          <div class="col-lg-4">
            <div class="pricingTable">
              <div class="pricingHeader"><h1>FREE</h1></div>
              <div class="triangleWhite"><img src="images/triangleWhite.png" alt="triangle" /></div>
              <div class="priceAmount"><h2>$0.00 <br/><span>per month</span></h2></div>
              <ul>
                <li>10 GB limited storage</li>
                <li>Lorem Ipsum</li>
                <li>Aliquam laoreet tellus</li>
                <li>Aliquam laoreet</li>
                <li>Lorem Ipsum</li>
              </ul>
              <div class="buttonContainer"><a href="#" class="buttonSmall">Purchase</a></div>
            </div>
          </div>

          <div class="col-lg-4">
            <div class="pricingTable">
              <div class="pricingHeader"><h1>STANDARD</h1></div>
              <div class="triangleWhite"><img src="images/triangleWhite.png" alt="triangle" /></div>
              <div class="priceAmount"><h2>$4.00 <br/><span>per month</span></h2></div>
              <ul>
                <li>25 GB limited storage</li>
                <li>Lorem Ipsum</li>
                <li>Aliquam laoreet tellus</li>
                <li>Aliquam laoreet</li>
                <li>Lorem Ipsum</li>
              </ul>
              <div class="buttonContainer"><a href="#" class="buttonSmall">Purchase</a></div>
            </div>
          </div>

          <div class="col-lg-4">
            <div class="pricingTable">
              <div class="pricingHeader"><h1>PREMIUM</h1></div>
              <div class="triangleWhite"><img src="images/triangleWhite.png" alt="triangle" /></div>
              <div class="priceAmount"><h2>$8.00 <br/><span>per month</span></h2></div>
              <ul>
                <li>50 GB limited storage</li>
                <li>Lorem Ipsum</li>
                <li>Aliquam laoreet tellus</li>
                <li>Aliquam laoreet</li>
                <li>Lorem Ipsum</li>
              </ul>
              <div class="buttonContainer"><a href="#" class="buttonSmall">Purchase</a></div>
            </div>
          </div>

        </div><!-- END Row -->
      </div><!-- END Container -->
    </section><!-- END Pricing -->

    <!-- Start Testimonials -->
    <section id="testimonials">
      <div class="container">
        <div class="row">
          <ul class="slides2">
            <li>
              <div class="col-lg-2"><img src="images/testimonialImage.png" alt="" /></div>
              <div class="col-lg-10">
              <h1><span>"</span>Vertex is the most incredible app out there! Lorem ipsum dolor amet, consectetur adipiscing 
              elit. Aenean leo lectus sollicitudin convallis quis eget libero. Sed non risus eget dolor.</h1>
              <p><span><a href="#">John Doe</a></span> / Web Developer</p>
              </div>
            </li>
            <li>
              <div class="col-lg-2"><img src="images/testimonialImage.png" alt="" /></div>
              <div class="col-lg-10">
              <h1><span>"</span>Vertex is the most incredible app out there! Lorem ipsum dolor amet, consectetur adipiscing 
              elit. Aenean leo lectus sollicitudin convallis quis eget libero. Sed non risus eget dolor.</h1>
              <p><span><a href="#">John Anderson</a></span> / Web Designer</p>
              </div>
            </li>
            <li>
              <div class="col-lg-2"><img src="images/testimonialImage.png" alt="" /></div>
              <div class="col-lg-10">
              <h1><span>"</span>Vertex is the most incredible app out there! Lorem ipsum dolor amet, consectetur adipiscing 
              elit. Aenean leo lectus sollicitudin convallis quis eget libero. Sed non risus eget dolor.</h1>
              <p><span><a href="#">Peter Parker</a></span> / Web Designer</p>
              </div>
            </li>
          </ul>
        </div><!-- END Row -->
      </div><!-- END Container -->
    </section><!-- END Testimonials -->

    <!-- Start faq-->
    <section id="faq">
      <a class="anchor" id="faqAnchor"></a>
      <div class="container">
        <div class="row"><div class="col-lg-12"><h3>Faq</h3></div><div class="col-lg-12"><img class="dividerWide" src="images/divider.png" alt=""></div></div>
          <div class="row">
            <div class="col-lg-4">
              <ul class="tabs">
                <li><a href="#tab1">What do I need to use Vertex?</a></li>
                <li><a href="#tab2">How do I make a payment?</a></li>
                <li><a href="#tab3">How can I upgrade my subscription?</a></li>
                <li><a href="#tab4">How do I cancel my subscription?</a></li>
                <li><a href="#tab5">How do I find friends on Vertex?</a></li>
              </ul>
            </div>
            <div class="col-lg-8 tabContent">
              <div id="tab1">
                <p><span>What do I need to use Vertex?</span><br/><br/> Lorem ipsum dolor amet, consectetur adipiscing elit. Aenean leo lectus sollicitudin 
                convallis quis eget libero. Aliquam laoreet tellus ut libero semper, egestas velit 
                malesuada. Sed non risus eget dolor vestibulum ullamcorper. Integer feugiat at massa 
                sit amet molestie. Sed non risus eget dolor vestibulum ullamcorper. Integer feugiat at massa 
                sit amet molestie. </p>
                <p>Fusce varius tincidunt metus ac accumsan. Sed varius pharetra risus 
                ac scelerisque. Nulla facilisi. Nulla facilisi. Vivamus metus lorem, pellentesque a a
                ccumsan quis, imperdiet nec quam. </p>
              </div>
              <div id="tab2">
                <p><span>How do I make a payment?</span><br/><br/> Lorem ipsum dolor amet, consectetur adipiscing elit. Aenean leo lectus sollicitudin 
                convallis quis eget libero. Aliquam laoreet tellus ut libero semper, egestas velit 
                malesuada. Sed non risus eget dolor vestibulum ullamcorper. Integer feugiat at massa 
                sit amet molestie.</p>
              </div>
              <div id="tab3">
                <p><span>How can I upgrade my subscription?</span><br/><br/> Lorem ipsum dolor amet, consectetur adipiscing elit. Aenean leo lectus sollicitudin 
                convallis quis eget libero. Aliquam laoreet tellus ut libero semper, egestas velit 
                malesuada. Sed non risus eget dolor vestibulum ullamcorper. Integer feugiat at massa 
                sit amet molestie.</p>
                <p>Fusce varius tincidunt metus ac accumsan. Sed varius pharetra risus 
                ac scelerisque. Nulla facilisi. Nulla facilisi. Vivamus metus lorem, pellentesque a a
                ccumsan quis, imperdiet nec quam. Sed non risus eget dolor vestibulum ullamcorper. 
                Integer feugiat at massa sit amet molestie. Fusce varius tincidunt metus ac accumsan. 
                Sed varius pharetra risus ac scelerisque.</p>
              </div>
              <div id="tab4">
                <p><span>How do I cancel my subscription?</span><br/><br/> Lorem ipsum dolor amet, consectetur adipiscing elit. Aenean leo lectus sollicitudin 
                convallis quis eget libero. Aliquam laoreet tellus ut libero semper, egestas velit 
                malesuada. Sed non risus eget dolor vestibulum ullamcorper. Integer feugiat at massa 
                sit amet molestie.</p>
              </div>
              <div id="tab5">
                <p><span>How do I find my friends on Vertex?</span><br/><br/> Lorem ipsum dolor amet, consectetur adipiscing elit. Aenean leo lectus sollicitudin 
                convallis quis eget libero. Aliquam laoreet tellus ut libero semper, egestas velit 
                malesuada. Sed non risus eget dolor vestibulum ullamcorper. Integer feugiat at massa 
                sit amet molestie.</p>
              </div>
            </div>
          </div><!-- END Row -->
      </div><!-- END Container -->
    </section><!-- END Faq -->

    <!-- Start Our Team -->
    <section id="ourTeam">
      <a class="anchor" id="ourTeamAnchor"></a>
      <div class="container">
        <div class="row"><div class="col-lg-12"><h3>Our Team</h3></div><div class="col-lg-12"><img class="dividerWide" src="images/divider.png" alt=""></div></div>
        <div class="row">
          <div class="col-lg-6 teamMemberInfo">
            <img class="teamImage" src="images/teamImage1.png" alt="" />
            <div class="col-lg-7 teamText">
            <h4><span>John Doe</span> / Designer</h4>
            <p>Lorem ipsum dolor non, consectetur adipiscing 
            elit. Aenean lectus sollicitudin convallis quis 
            libero. Aliquam laoreet tellus ut libero semper, 
            egestas velit malesuada. Sed non risus eget 
            dolor vestibulum ullamcorper. Integer feugiat 
            massa molestie.</p>
            <ul class="socialIcons">
              <li><a href="#" class="fbIcon" target="_blank"></a></li>
              <li><a href="#" class="twitterIcon" target="_blank"></a></li>
              <li><a href="#" class="googleIcon" target="_blank"></a></li>
              <li><a href="#" class="flickrIcon" target="_blank"></a></li>
            </ul>
            </div>
          </div>
          <div class="col-lg-6 teamMemberInfo">
            <img class="teamImage" src="images/teamImage2.png" alt="" />
            <div class="col-lg-7 teamText">
            <h4><span>Sally Doe</span> / Developer</h4>
            <p>Lorem ipsum dolor non, consectetur adipiscing 
            elit. Aenean lectus sollicitudin convallis quis 
            libero. Aliquam laoreet tellus ut libero semper, 
            egestas velit malesuada. Sed non risus eget 
            dolor vestibulum ullamcorper. Integer feugiat 
            massa molestie.</p>
            <ul class="socialIcons">
              <li><a href="#" class="fbIcon" target="_blank"></a></li>
              <li><a href="#" class="twitterIcon" target="_blank"></a></li>
              <li><a href="#" class="googleIcon" target="_blank"></a></li>
              <li><a href="#" class="flickrIcon" target="_blank"></a></li>
            </ul>
            </div>
          </div>
        </div><!-- END Row -->
      </div><!-- END Container -->
    </section><!-- END Our team -->

    <!-- Start Contact -->
    <section id="contact">
      <a class="anchor" id="contactAnchor"></a>
      <div class="container">
        <div class="row"><div class="col-lg-12"><h3>Get In Touch</h3></div></div>
        <div class="row">
          <div class="col-lg-8 col-lg-offset-2">
            <p>Lorem ipsum dolor amet, consectetur adipiscing elit. Aenean leo lectus sollicitudin convallis quis.</p>
            <!-- Start contact form -->
            <form id="contactForm" method="post" action="index.php">

              <label style="display:none;" class="screen-reader-text">Name</label>
                <?php if($nameError != '') { ?>
                  <br /><span class="error"><?php echo $nameError;?></span> 
                <?php } ?>
              <input type="text" name="name" placeholder="Your name" class="contactInput requiredField" id="contactInputName" value="<?php if(isset($_POST['name'])) echo $_POST['name'];?>" />

              <label style="display:none;" class="screen-reader-text">Email</label> 
                <?php if($emailError != '') { ?>
                  <br /><span class="error"><?php echo $emailError;?></span>
                <?php } ?>
              <input type="text" name="email" placeholder="Your email" class="contactInput requiredField email" id="contactInputEmail" style="margin-right:0px" /><br/>

              <label style="display:none;" class="screen-reader-text">Message</label>
                <?php if($commentError != '') { ?>
                  <br /><span class="error"><?php echo $commentError;?></span> 
                <?php } ?>
              <textarea name="message" placeholder="Your message" class="contactMessage requiredField"></textarea>

              <input type="submit" name="submit" value="Send Message" class="buttonSmall" /><br/><br/>
              <input type="hidden" name="submitted" id="submitted" value="true" />

            </form>
            <!-- END Contact form -->
          </div>
        </div><!-- END Row -->
      </div><!-- END Container -->
    </section><!-- END Contact -->

    <footer>
      <div class="container">
        <div class="row">
          <div class="col-lg-4 about">
            <a href="#" class="logoDark"></a><br/><br/>
            <p>Lorem ipsum dolor amet, consectetur adipiscing elit. Aenean 
            leo lectus sollicitudin convallis eget libero. Aliquam laoreet 
            tellus ut libero semper, egestas velit malesuada. Sed non 
            risus eget dolor amet vestibulum ullamcorper. Integer feugiat 
            molestie.</p>
            <ul class="socialIcons">
              <li><a href="#" class="fbIcon" target="_blank"></a></li>
              <li><a href="#" class="twitterIcon" target="_blank"></a></li>
              <li><a href="#" class="googleIcon" target="_blank"></a></li>
              <li><a href="#" class="flickrIcon" target="_blank"></a></li>
            </ul>
          </div>
          <div class="col-lg-4 twitter">
            <h4>Latest Tweets</h4>
            <ul>
              <li><a href="#">@John Doe</a> Lorem ipsum dolor amet, consectetur adipiscing 
              elit. Aenean leo lectus sollicitudin eget libero.<br/><span>2 minutes ago</span></li>
              <li><a href="#">@John Doe</a> Lorem ipsum dolor amet, consectetur adipiscing 
              elit. Aenean leo lectus sollicitudin eget libero.<br/><span>About an hour ago</span></li>
            </ul>
          </div>
          <div class="col-lg-4 contact">
            <h4>Contact Info</h4>
            <p>Lorem ipsum dolor amet, consectetur adipiscing ipsum dolor.</p>
            <ul>
              <li><img src="images/icons/footerPhone.png" alt="phone icon" />1-123-345-6789</li>
              <li><img src="images/icons/footerPin.png" alt="pin icon" /><a href="#">contact@vertexTheme.com</a></li>
              <li><img src="images/icons/footerMail.png" alt="mail icon" />123 Smith Drive, Baltimore, MD 21212</li>
            </ul>
          </div>
        </div><!-- END Row -->
      </div><!-- END Container -->
    </footer><!-- END Footer -->
    
<!-- JavaScript file links -->
<script src="js/jquery.js"></script>			<!-- Jquery -->
<script src="js/bootstrap.min.js"></script>		<!-- bootstrap -->
<script src="js/jquery.bxslider.min.js"></script>  <!-- bxslider -->
<script src="js/tabs.js"></script> <!-- custom tab script -->
<script src="js/lightbox-2.6.min.js"></script>  <!-- lightbox -->
<script src="js/jquery.scrollTo.js"></script>  <!-- scollTo -->
<script src="js/jquery.nav.js"></script>  <!-- one page nav -->
<script src="js/respond.js"></script>

<script>
  "use strict";
  // ACTIVATE BXSLIDER (for slider section)
  $(document).ready(function(){
    $('.slides').fadeIn().bxSlider({
      auto: true,
      pager: false,
      nextSelector: '#slider-next',
      prevSelector: '#slider-prev',
      nextText: '<img src="images/nextButton.png" alt="slider next" />',
      prevText: '<img src="images/prevButton.png" alt="slider prev" />',
      // triggers slider animations on slide change
      onSlideBefore: function(){
        $('.jumbotron img').addClass("fadeInReallyFast"); 
        $('.jumbotron h1').addClass("fadeInFast");  
        $('.jumbotron p').addClass("fadeInMed"); 
        $('.jumbotron .button').addClass("fadeInSlow"); 
        $('.jumbotron .buttonSmall').addClass("fadeInSlow"); 
        $('#emailInputSlider').addClass("fadeInSlow"); 

        setTimeout (function(){
        $('.jumbotron img').removeClass("fadeInReallyFast"); 
        $('.jumbotron h1').removeClass("fadeInFast");  
        $('.jumbotron p').removeClass("fadeInMed"); 
        $('.jumbotron .button').removeClass("fadeInSlow"); 
        $('.jumbotron .buttonSmall').removeClass("fadeInSlow"); 
        $('#emailInputSlider').removeClass("fadeInSlow"); 
        }, 1400);
      }
    });

    //Triggers slider animations on page load
    $(document).ready(function() {
        $('.jumbotron img').toggleClass("fadeInReallyFast"); 
        $('.jumbotron h1').toggleClass("fadeInFast"); 
        $('.jumbotron p').toggleClass("fadeInMed"); 
        $('.jumbotron .button').toggleClass("fadeInSlow"); 
        $('.jumbotron .buttonSmall').toggleClass("fadeInSlow"); 
        $('#emailInputSlider').toggleClass("fadeInSlow"); 

        setTimeout (function(){
        $('.jumbotron img').removeClass("fadeInReallyFast"); 
        $('.jumbotron h1').removeClass("fadeInFast");  
        $('.jumbotron p').removeClass("fadeInMed"); 
        $('.jumbotron .button').removeClass("fadeInSlow"); 
        $('.jumbotron .buttonSmall').removeClass("fadeInSlow"); 
        $('#emailInputSlider').removeClass("fadeInSlow"); 
        }, 1400);
    });

    //activate second bxslider (for testimonials section)
    $('.slides2').bxSlider({
      auto: true,
      controls: false
    });
    });


// ACTIVATE ONE PAGE NAV 
$(document).ready(function() {
    $('.nav.navbar-nav.navbar-right').onePageNav();
});
</script>

<script>
"use strict";
// SCREENSHOT IMAGE HOVERS
$('.image').mouseover(function()
{
    $(".overlay", this).stop(true, true).fadeIn();
}); 

$('.image').mouseout(function()
{
    $(".overlay", this).stop(true, true).fadeOut();
}); 
</script>

<!-- CONTACT FORM -->
<script type="text/javascript">
  <!--//--><![CDATA[//><!--
  $(document).ready(function() {
    $('form#contactForm').submit(function() {
      $('form#contactForm .error').remove();
      var hasError = false;
      $('.requiredField').each(function() {
        if($.trim($(this).val()) == '') {
          var labelText = $(this).prev('label').text();
          $(this).parent().append('<span class="error">You forgot to enter your '+labelText+'.</span>');
          $(this).addClass('inputError');
          hasError = true;
        } else if($(this).hasClass('email')) {
          var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
          if(!emailReg.test($.trim($(this).val()))) {
            var labelText = $(this).prev('label').text();
            $(this).parent().append('<span class="error">Sorry! You\'ve entered an invalid '+labelText+'.</span>');
            $(this).addClass('inputError');
            hasError = true;
          }
        }
      });
      if(!hasError) {
        var formInput = $(this).serialize();
        $.post($(this).attr('action'),formInput, function(data){
          $('form#contactForm').slideUp("fast", function() {          
            $(this).before('<p class="tick"><strong>Thanks!</strong> Your email has been delivered!</p>');
          });
        });
      }
      
      return false; 
    });
  });
  //-->!]]>
</script>

</body>
</html>
